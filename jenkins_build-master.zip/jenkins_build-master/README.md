# xinwei-example
北京鑫为科技出品

# 演示 wrapper 插件使用

# 涉及到的相关技术点
maven，spring boot，wrapper
